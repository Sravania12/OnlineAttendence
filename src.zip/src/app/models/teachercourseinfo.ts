export interface TeacherCourseInfo {
  id?: number;
  courseId: number;
  staffId: number;
}
