export interface StudentCourseAssignation{
  staffId: number;
  courseIds: number[];
  studentIds: number[];
}
