export interface User {
    staffId: number;
    staffName: string;
    mobileNumber: number;
    email: string;
    password: string;
    gender: string;
}