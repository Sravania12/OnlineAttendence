export interface CourseInfo {
  courseId?: number;
  courseName: string;
  courseBranch: string;
  courseDescription: string;
}
