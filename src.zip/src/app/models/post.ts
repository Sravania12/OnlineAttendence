export interface Post {
    studentId: number;
    name: string;
    branch: string;
    gender:string;
    email:string;
    password:string;

}
