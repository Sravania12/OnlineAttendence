export interface Attendence {
  [x: string]: any;
      sno: number;
      studentId: number;
      staffId: number;
      date: number;
      presentStatus:string;
  }
