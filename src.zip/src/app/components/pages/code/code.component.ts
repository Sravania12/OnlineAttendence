import { Component } from '@angular/core';

@Component({
  selector: 'app-about',
  templateUrl: './code.component.html',
  styleUrls: ['./code.component.css']
})
export class codeComponent {

}
