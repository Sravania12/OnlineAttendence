import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sindex',
  templateUrl: './sindex.component.html',
  styleUrls: ['./sindex.component.css']
})
export class SindexComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
