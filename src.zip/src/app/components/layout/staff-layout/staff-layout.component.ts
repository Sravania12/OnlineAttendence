import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-staff-layout',
  templateUrl: './staff-layout.component.html',
  styleUrls: ['./staff-layout.component.css']
})
export class StaffLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
