import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators} from '@angular/forms';
import { ActivatedRoute } from '@angular/router';



@Component({
  selector: 'app-editeachercourse',
  templateUrl: './editeachercourse.component.html',
  styleUrls: ['./editeachercourse.component.css']
})
export class EditeachercourseComponent implements OnInit {




  constructor(
  ) { }

  ngOnInit(): void {






  }


}
