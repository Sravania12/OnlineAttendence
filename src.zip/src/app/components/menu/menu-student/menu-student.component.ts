import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menu-student',
  templateUrl: './menu-student.component.html',
  styleUrls: ['./menu-student.component.css']
})
export class MenuStudentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
