import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menu-staff',
  templateUrl: './menu-staff.component.html',
  styleUrls: ['./menu-staff.component.css']
})
export class MenuStaffComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
